import csv
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


def load_data(filepath):
    df = pd.read_excel(filepath)
    data = df[['时间', '辐照强度w/m2']].values
    really_time = data[:, 0]
    light = data[:, 1]
    print("时间:", really_time)
    print("辐照强度:", light)
    return really_time, light


def chafun(really_time, light):
    x = []
    length = len(really_time)
    for i in range(length):
        if i < length - 2:
            a = light[i]
            b = light[i + 1]
            c = light[i + 2]
            if (b - a) * (b - c) > 0 and (b - a) ** 2 > (a * 0.2) ** 2 and (b - c) ** 2 > (c / 5) ** 2:
                x.append((a + c) / 2)
            else:
                x.append(light[i])
        else:
            x.append(light[i])
    return x


def find_zero_to_one_transitions(light):
    transitions = []
    for i in range(len(light) - 1):
        if light[i] == 0 and light[i + 1] == 1:
            transitions.append(i)
    return transitions


def process_anomaly_block(light, start, end, transitions):
    # 找到异常数据块之前的多个相邻的 0 到 1 的点作为周期基准点
    prev_transitions = [t for t in transitions if t < start]
    if len(prev_transitions) < 2:
        return light

    periods = []
    for i in range(len(prev_transitions) - 1):
        periods.append(prev_transitions[i + 1] - prev_transitions[i])
    base_period = int(np.mean(periods))

    # 对异常数据块进行残差拟合补值
    for i in range(start, end):
        residuals = []
        for p in periods:
            index = prev_transitions[-1] + (i - start) % p
            if index < len(light):
                residuals.append(light[index])
        if residuals:
            light[i] = np.mean(residuals)

    return light


def process_anomaly_data(light):
    in_anomaly = False
    anomaly_start = None
    transitions = find_zero_to_one_transitions(light)
    anomaly_intervals = []

    # 查找差值超过 100 的点
    for i in range(len(light) - 1):
        if abs(light[i + 1] - light[i]) > 100:
            j = i + 1
            count_zero_one = 0
            while j < len(light):
                if light[j] in [0, 1]:
                    count_zero_one += 1
                else:
                    break
                j += 1
            if count_zero_one > 50:
                if not in_anomaly:
                    in_anomaly = True
                    anomaly_start = i
                if in_anomaly:
                    in_anomaly = False
                    anomaly_intervals.append((anomaly_start, j))
                    light = process_anomaly_block(light, anomaly_start, j, transitions)

    if anomaly_intervals:
        print("异常区间如下：")
        for start, end in anomaly_intervals:
            print(f"起始索引: {start}, 结束索引: {end}")
    else:
        print("未发现异常区间。")

    return light


def visualize_data(really_time, light):
    limited_time = really_time[:480 * 3]
    limited_light = light[:480 * 3]
    plt.plot(limited_time, limited_light, label='Light Data')
    plt.xlabel('Time')
    plt.ylabel('Light (w/m2)')
    plt.legend()
    plt.show()


if __name__ == "__main__":
    filepath = "/home/mtftau-5/workplace/2025赛题/2025赛题/2025_A题/附件/电站1环境检测仪数据.xlsx"
    really_time, light = load_data(filepath)

    x = chafun(really_time, light)
    x = process_anomaly_data(x)

    csv_filename = 'filtered_light_data.csv'
    with open(csv_filename, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['时间', '辐照强度'])
        for time, light_value in zip(really_time, x):
            writer.writerow([time, light_value])
    print(f"Filtered data saved to {csv_filename}")
    visualize_data(really_time, x)
    