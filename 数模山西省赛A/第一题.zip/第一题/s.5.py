import csv
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


def load_data(filepath):
    df = pd.read_excel(filepath)
    data = df[['时间', '辐照强度w/m2']].values
    really_time = data[:, 0]
    light = data[:, 1]
    print("时间:", really_time)
    print("辐照强度:", light)
    return really_time, light


def chafun(really_time, light):
    x = []
    length = len(really_time)
    for i in range(length):
        if i < length - 2:
            a = light[i]
            b = light[i + 1]
            c = light[i + 2]
            if (b - a) * (b - c) > 0 and (b - a) ** 2 > (a * 0.) ** 2 and (b - c) ** 2 > (c * 0.3) ** 2:
                x.append((a + c) / 2)
            else:
                x.append(light[i])
        else:
            x.append(light[i])
    return x


def find_period(light):
    first_zero_crossing = None
    second_zero_crossing = None
    for i in range(len(light) - 1):
        if light[i] == 0 and light[i + 1] > 0:
            if first_zero_crossing is None:
                first_zero_crossing = i
            elif second_zero_crossing is None:
                second_zero_crossing = i
                break
    if first_zero_crossing is not None and second_zero_crossing is not None:
        return second_zero_crossing - first_zero_crossing
    return None


def multi_sample_average(light, period, num_samples=3):
    avg_light = np.zeros(period)
    valid_samples = 0
    for sample in range(num_samples):
        start = sample * period
        if start + period <= len(light):
            avg_light += light[start:start + period]
            valid_samples += 1
    if valid_samples > 0:
        avg_light /= valid_samples
    return avg_light


def residual_estimation(light, avg_light, period):
    new_light = light.copy()
    for i in range(len(light)):
        period_index = i % period
        if light[i] == 0:
            new_light[i] = avg_light[period_index]
        else:
            residual = light[i] - avg_light[period_index]
            if abs(residual) > 0.1 * avg_light[period_index]:
                new_light[i] = avg_light[period_index] + 0.5 * residual
    return new_light


def fill_gap_with_period(light, avg_light, period):
    new_light = light.copy()
    gap_start = None
    for i in range(len(light)):
        if light[i] == 0:
            if gap_start is None:
                gap_start = i
        else:
            if gap_start is not None:
                gap_end = i
                gap_length = gap_end - gap_start
                if gap_length > 1000:
                    # 对长度大于 1000 的空缺段进行周期划分
                    for j in range(gap_start, gap_end):
                        sub_period_index = (j - gap_start) % period
                        new_light[j] = avg_light[sub_period_index]
                gap_start = None
    # 处理末尾的空缺段
    if gap_start is not None:
        gap_end = len(light)
        gap_length = gap_end - gap_start
        if gap_length > 1000:
            for j in range(gap_start, gap_end):
                sub_period_index = (j - gap_start) % period
                new_light[j] = avg_light[sub_period_index]
    return new_light


def find_zero_to_one_transitions(light):
    transitions = []
    for i in range(len(light) - 1):
        if light[i] == 0 and light[i + 1] == 1:
            transitions.append(i)
    return transitions


def process_anomaly_block(light, start, end, avg_light, period):
    # 仅对异常数据块中的 0 和 1 进行补值
    for i in range(start, end):
        if light[i] in [0, 1]:
            period_index = i % period
            light[i] = avg_light[period_index]
    return light


def process_anomaly_data(light, avg_light, period):
    in_anomaly = False
    anomaly_start = None
    anomaly_intervals = []

    # 查找差值超过 100 的点
    for i in range(len(light) - 1):
        if abs(light[i + 1] - light[i]) > 100:
            j = i + 1
            count_small_values = 0
            while j < len(light):
                if light[j] in [0, 1]:
                    count_small_values += 1
                else:
                    break
                j += 1
            if count_small_values > 20:
                if not in_anomaly:
                    in_anomaly = True
                    anomaly_start = i
                if in_anomaly:
                    in_anomaly = False
                    anomaly_intervals.append((anomaly_start, j))

    # 对每个异常区间进行处理
    for start, end in anomaly_intervals:
        light = process_anomaly_block(light, start, end, avg_light, period)

    if anomaly_intervals:
        print("异常区间如下：")
        for start, end in anomaly_intervals:
            print(f"起始索引: {start}, 结束索引: {end}")
    else:
        print("未发现异常区间。")

    return light


def process_specific_anomaly_block(light, start, end, avg_light, period):
    # 强制对指定范围内的 0 和 1 进行补值
    for i in range(start, end):
        if light[i] in [0, 1]:
            period_index = i % period
            light[i] = avg_light[period_index]
    return light


def estimate_missing_values(light, avg_light, period):
    """
    使用相邻有效数据的残差进行估计，并用完整周期预测所有空缺值（0 和 1）。
    """
    new_light = light.copy()
    for i in range(len(light)):
        if light[i] in [0, 1]:  # 仅处理空缺值
            # 找到前一个有效数据点
            prev_index = i - 1
            while prev_index >= 0 and light[prev_index] in [0, 1]:
                prev_index -= 1

            # 找到后一个有效数据点
            next_index = i + 1
            while next_index < len(light) and light[next_index] in [0, 1]:
                next_index += 1

            # 计算残差并进行估计
            period_index = i % period
            if prev_index >= 0 and next_index < len(light):
                # 使用前后有效数据点的残差进行插值
                prev_residual = light[prev_index] - avg_light[prev_index % period]
                next_residual = light[next_index] - avg_light[next_index % period]
                estimated_value = avg_light[period_index] + (prev_residual + next_residual) / 2
            elif prev_index >= 0:
                # 仅使用前一个有效数据点的残差
                prev_residual = light[prev_index] - avg_light[prev_index % period]
                estimated_value = avg_light[period_index] + prev_residual
            elif next_index < len(light):
                # 仅使用后一个有效数据点的残差
                next_residual = light[next_index] - avg_light[next_index % period]
                estimated_value = avg_light[period_index] + next_residual
            else:
                # 无法找到前后有效数据点，直接使用周期平均值
                estimated_value = avg_light[period_index]

            new_light[i] = estimated_value
    return new_light


def visualize_data(really_time, light):
    limited_time = really_time[:480 * 3]
    limited_light = light[:480 * 3]
    plt.plot(limited_time, limited_light, label='Light Data')
    plt.xlabel('Time')
    plt.ylabel('Light (w/m2)')
    plt.legend()
    plt.show()


if __name__ == "__main__":
    filepath = "/home/mtftau-5/workplace/2025赛题/2025赛题/2025_A题/附件/电站1环境检测仪数据.xlsx"
    really_time, light = load_data(filepath)

    # 清洗数据
    cleaned_light = chafun(really_time, light)

    # 找到周期
    period = find_period(cleaned_light)
    print(f"找到的周期为: {period}")

    if period is not None:
        # 多次采样取平均值
        avg_light = multi_sample_average(cleaned_light, period)

        # 使用残差估计并预测所有空缺值
        processed_light = estimate_missing_values(cleaned_light, avg_light, period)
    else:
        processed_light = cleaned_light
        print("未找到周期，无法进行空缺值预测。")

    # 保存结果
    excel_filename = '辐照数据（已清洗并预测）.xlsx'
    df = pd.DataFrame({'时间': really_time, '辐照强度': processed_light})
    df.to_excel(excel_filename, index=False)
    print(f"Filtered and predicted data saved to {excel_filename}")

    visualize_data(really_time, processed_light)
