import numpy as np
import pandas as pd
import csv
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt


def load_data(filepath):
    df = pd.read_csv(filepath)
    data = df[['时间', '发电量']].values
    really_time = data[:, 0]
    power = data[:, 1]
    print("时间:", really_time)
    print("发电量:", power)
    return really_time, power

def rechange_power(power):
    new_power = []
    i = 0
    while i < len(power) - 1:
        if power[i] > power[i + 1]:
            # 找到第一个大于当前值的元素
            for j in range(i + 1, len(power)):
                if power[j] > power[i]:
                    slope = (power[j] - power[i]) / (j - i)
                    for k in range(j - i):
                        new_power.append(power[i] + slope * k)
                    i = j
                    break
            else:

                new_power.append(power[i])
                i += 1
        else:
            new_power.append(power[i])
            i += 1
    # 添加最后一个元素
    new_power.append(power[-1])
    return new_power

really_time, power = load_data("/home/mtftau-5/workplace/数模/输出文件/电站1时间转化.csv")

new_power = rechange_power(power)

# 创建一个 DataFrame
df = pd.DataFrame({
    '时间': really_time,
    '发电量': new_power
})

# 保存为 CSV 文件
csv_file_path = "/home/mtftau-5/workplace/数模/输出文件/电站1时间转化_新数据.csv"
df.to_csv(csv_file_path, index=False)

print(f"数据已保存到 {csv_file_path}")
